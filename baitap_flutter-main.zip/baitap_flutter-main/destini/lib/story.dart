class Story {
  String storyTitle="";
  String choice1="";
  String choice2="";

  Story({String stitle='', String c1='', String c2=''}){
    storyTitle = stitle;
    choice1 = c1;
    choice2 = c2;
  }
}
