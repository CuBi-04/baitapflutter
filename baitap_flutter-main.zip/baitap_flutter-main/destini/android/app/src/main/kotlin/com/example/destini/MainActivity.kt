package com.example.destini

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
