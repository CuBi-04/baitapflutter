class Question {
  String question;
  bool correctAnswer;

  Question(this.question, this.correctAnswer);
}
