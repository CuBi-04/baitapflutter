package com.example.magic_eight_ball

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
