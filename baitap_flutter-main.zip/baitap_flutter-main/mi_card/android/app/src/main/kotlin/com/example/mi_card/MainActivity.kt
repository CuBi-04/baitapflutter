package com.example.mi_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
